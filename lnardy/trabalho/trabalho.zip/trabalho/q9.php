<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabalho Q09</title>
</head>
<body>

<form method= "POST">
    <button type= "submit">girar dado</button>
    <br>
    <br>
</form>

</body>
</html>

<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){

$array = [];
for ($i = 0; $i <= 199; $i++){
    $valores = random_int(1, 6);
    $array[$i] = $valores; 
}

$frequencia = array_count_values($array);

foreach ($frequencia as $num => $contagem){
    $porcentagem = ($contagem / count($array)) * 100;
    echo "o número $num aparece $contagem vezes, que é $porcentagem% do total; <br>";
}



}

