<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabalho Q11</title>
</head>
<body>
    
<form method="POST">
<label>digite 9 valores para formar uma matriz:</label><br>
<?php

for($i = 0; $i <= 8; $i++){
    echo "<input type='number' name='num[]' required>";
}
?>

<br>
<input type="submit"><Enviar>
<br>

</form>

</body>
</html>

<?php 

if($_SERVER["REQUEST_METHOD"] == "POST"){

$num = $_POST['num'];
$matriz = array_chunk($num, 3); //serve para dividir o array em multiplos arrays menores

$num = $_POST["num"];
for ($i = 0; $i <= 8; $i++){
    $matriz[$i] = $num[$i];
}

$valor1 = $matriz[0];
$valor2 = $matriz[4];
$valor3 = $matriz[8];

$soma = $valor1 + $valor2 + $valor3;

echo "a soma dos elementos da diagonal principal da matriz é $soma";

}
