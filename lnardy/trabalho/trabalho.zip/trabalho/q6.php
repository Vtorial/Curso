<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabalho Q06</title>
</head>
<body>

    <form method = "POST">
    <label>Digite os valores da matriz:</label>
        <input type="number" name="num1" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num2" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num3" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num4" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num5" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num6" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num7" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num8" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num9" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num10" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num11" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num12" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num13" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num14" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num15" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num16" required><br>
        <br>
        <input type="submit" value="enviar">

    </form>

</body>
</html>

<?php

if($_SERVER["REQUEST_METHOD"] == "POST"){
  
$a1 = $_POST['num1'];
$a2 = $_POST['num2'];
$a3 = $_POST['num3'];
$a4 = $_POST['num4'];
$a5 = $_POST['num5'];
$a6 = $_POST['num6'];
$a7 = $_POST['num7'];
$a8 = $_POST['num8'];
$a9 = $_POST['num9'];
$a10 = $_POST['num10'];
$a11 = $_POST['num11'];
$a12 = $_POST['num12'];
$a13 = $_POST['num13'];
$a14 = $_POST['num14'];
$a15 = $_POST['num15'];
$a16 = $_POST['num16'];

$matriz = array( 
          array ($a1, $a2, $a3, $a4),
          array ($a5, $a6, $a7, $a8),
          array ($a9, $a10, $a11, $a12),
          array ($a13, $a14, $a15, $a16)
        );

        function iguais($matriz) {
        $valor1 = $matriz[0][0];
        foreach ($matriz as $valor){
         if ($valor == $valor1){
        return true;
     }
        } return false;
    }

        function repetido($matriz){
        $valores = array();
        foreach ($matriz as $valor){
        if (in_array($valor, $valores)){
            return true;
    }
        $valores[] = $valor;
    }
        return false;
    }

    if(iguais($matriz)){
        echo "Matriz é igual";
    } 
    elseif (repetido($matriz)){
        echo "Matriz tem repetidos";
    }
    else{
        echo "Matriz têm valores diferentes";
    }
    

}