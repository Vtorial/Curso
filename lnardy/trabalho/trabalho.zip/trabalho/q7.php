<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trablaho Q07</title>
</head>
<body>
    
<form method="POST">
        Digite os valores da matriz <br>
      
        <label></label>
        <input type="number" name="num1" required><br>
        <label></label>
        <input type="number" name="num2" required><br>
        <label></label>
        <input type="number" name="num3" required><br>
        <label></label>
        <input type="number" name="num4" required><br>

        <input type="submit" value="enviar">
        <br>
</form>

</body>
</html>

<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $m1 = $_POST["num1"];
    $m2 = $_POST["num2"];
    $m3 = $_POST["num3"];
    $m4 = $_POST["num4"];
    $array = array([$m1, $m2, $m3, $m4]);

    if ($array) {
        echo "a matriz invertida é <br>";
        echo "$m4, $m3 <br>"; 
        echo "$m2, $m1";
    }












    
}
