<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabalho Q04</title>
</head>
<body>
    
<form method="POST">
        <label>Digite um valor:</label>
        <input type="number" name="num1" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num2" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num3" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num4" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num5" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num6" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num7" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num8" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num9" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num10" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num11" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num12" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num13" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num14" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num15" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num16" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num17" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num18" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num19" min="0" required><br>
        <label>Digite outro valor:</label>
        <input type="number" name="num20" min="0" required><br>
        <br>
        <input type="submit" value="enviar">
    </form>

</body>
</html>

<?php

if($_SERVER["REQUEST_METHOD"] == "POST"){
    
$valor1 = $_POST['num1'];
$valor2 = $_POST['num2'];
$valor3 = $_POST['num3'];
$valor4 = $_POST['num4'];
$valor5 = $_POST['num5'];
$valor6 = $_POST['num6'];
$valor7 = $_POST['num7'];
$valor8 = $_POST['num8'];
$valor9 = $_POST['num9'];
$valor10 = $_POST['num10'];
$valor11 = $_POST['num11'];
$valor12 = $_POST['num12'];
$valor13 = $_POST['num13'];
$valor14 = $_POST['num14'];
$valor15 = $_POST['num15'];
$valor16 = $_POST['num16'];
$valor17 = $_POST['num17'];
$valor18 = $_POST['num18'];
$valor19 = $_POST['num19'];
$valor20 = $_POST['num20'];

$matriz = array($valor1, $valor2, $valor3, $valor4, $valor5, $valor6, $valor7, $valor8, $valor9, $valor10, $valor11, $valor12, $valor13, $valor14, $valor15, $valor16, $valor17, $valor18, $valor19, $valor20);

$soma = array_sum($matriz);
echo "a soma é $soma";

}