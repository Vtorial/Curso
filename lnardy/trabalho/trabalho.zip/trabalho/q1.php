<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabalho Q01</title>
</head>
<body>
    
<form method="POST">
        <label>Valor 2020:</label>
        <input type="number" name="num1" min="1" required><br>
        <label>Valor 2021:</label>
        <input type="number" name="num2" min="1" required><br>
        <label>Valor 2022:</label>
        <input type="number" name="num3" min="1" required><br>
        <label>Valor 2023:</label>
        <input type="number" name="num4" min="1" required>
        <br>
        <br>
        <input type="submit" value="enviar">
        <br>
        <br>
    </form>

</body>
</html>

<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){

$ano2020 = $_POST['num1'];
$ano2021 = $_POST['num2'];
$ano2022 = $_POST['num3'];
$ano2023 = $_POST['num4'];

$aumento = 0;
if($ano2020 > $ano2021){
  $aumento++;
}
if($ano2022 > $ano2021){
  $aumento++;
}
if($ano2021 > $ano2022){
  $aumento++;
}
if($ano2023 > $ano2022){
  $aumento++;
}

echo " teve $aumento ano(s) de aumento <br>";

if($ano2021 > $ano2020){
  $percentual1 = (($ano2021 - $ano2020) / $ano2020) * 100;
  echo "O percentual de crescimento do ano de 2020 em relação ao ano de 2021 é de $percentual1% <br>";
}else{
  echo "Não houve aumento de 2020 para 2021 <br>";
}

if($ano2022 > $ano2021){
  $percentual2 = (($ano2022 - $ano2021) / $ano2021) * 100;
  echo "O percentual de crescimento do ano de 2021 em relação ao ano de 2022 é de $percentual2% <br>";
}else{
  echo "Não houve aumento de 2021 para 2022 <br>";
}

if($ano2023 > $ano2022){
  $percentual4 = (($ano2023 - $ano2022) / $ano2022) * 100;
  echo "O percentual de crescimento do ano de 2023 em relação ao ano de 2022 é de $percentual4% <br>";
}else{
  echo "Não houve aumento de 2022 para 2023 <br>";
}

}