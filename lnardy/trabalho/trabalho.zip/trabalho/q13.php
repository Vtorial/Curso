<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabaho Q13</title>
</head>
<body>
    
<form method="POST">
<label>digite algum valor:</label>
<input type="number" name="valor" required>
<br>
<br>
<input type="submit" value="enviar">

</form>

</body>
</html>

<?php

if($_SERVER["REQUEST_METHOD"] == "POST"){

$valor = $_POST["valor"];
echo "os números pares de 0 até $valor são: <br>";
for($i = 0; $i <= $valor; $i++){
    if($i % 2 == 0){
        echo "$i <br>";}
    }

}

