<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabalho Q02</title>
</head>
<body>
    
<form method="POST">
    <label>digite a 1º nota entre 0 a 20:</label>
    <input type="number" name="teorica" min="0" max="20" required> <br>
    <label>digite a 2º nota entre 0 a 20:</label>
    <input type="number" name="pratica" min="0" max="20" required><br>
    <label>digite a 3º nota entre 0 a 20:</label>
    <input type="number" name="projeto" min="0" max="20" required><br>
    <br>
    <input type="submit" value="calcular"> 
</form>

</body>
</html>

<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $teorica = $_POST["teorica"];
    $pratica = $_POST["pratica"];
    $projeto = $_POST["projeto"];

    if($teorica < 0 || $teorica > 20 || $pratica < 0 || $pratica > 20 || $projeto < 0 || $projeto > 20){
        echo "Nota inválida, a nota deve ser em um intervalo de 0 a 20";
    }

    $notaF = (0.5 * $teorica) + (0.3 * $pratica) + (0.2 * $projeto);

   if($notaF > 30 || ($pratica >= 13 && $teorica >= 13)){
    echo "Aprovado <br>";
   }

   if($teorica == 8 || $teorica == 9 || $notaF > 14){
    echo "o aluno deve fazer o exame oral <br>";
   }

   $frequencias = ($teorica + $pratica) / 2;
   if($teorica >= 8 && $pratica >= 8 && $frequencias >=10){
    echo "frequências aprovadas <br>";
    }
    else{
        echo "frequências reprovadas<br>";
    } 
    
    if($notaF >= 10){
        echo "Aprovado";
    }
    else{
        echo "Reprovado";
    }
}