<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabalho Q08</title>
</head>
<body>
<form method="POST">
      
        <label>Digitem a data de seus aniversários:</label><br>
        <?php
            for ($i=0; $i < 40; $i++) { 
                echo "<input type='date' name='datas[]' required><br>";
            }
        ?>
        <br> 
        <input type="submit" value="enviar">
        <br>
</form>

</body>
</html>

<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){

$datas = [];
$datas = $_POST["datas"];

for ($i=0; $i < 40; $i++) { 
  $datas2 = new DateTime($datas[$i]);
  $idade = $datas2->diff(new DateTime())->y;
  $idades[] = $idade;
}

$idademax = max($idades);
$idademin = min($idades);
$idademed = array_sum($idades)/ count($idades);

echo "idade máxima: " . $idademax . "anos <br>";
echo "idade mínima: " . $idademin . "anos <br>";
echo "idade média: " . $idademed . "anos <br>";

}