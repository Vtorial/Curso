<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabalho  Q14</title>
</head>
<body>
    
<form method="POST">
    <label>digite um valor de 0 a 100:</label>
    <input type="number" name="valor" min="1" max="100" required>
<br>
<input type="submit"><Enviar>
<br>

<?php
session_start();
if(!isset($_SESSION['aleatorio'])){
    $_SESSION['aleatorio'] = random_int(1,100);
}
$aleatorio = $_SESSION['aleatorio'];
?>
<br>

</form>

</body>
</html>

<?php 

if($_SERVER["REQUEST_METHOD"] == "POST"){
    
    $valor = $_POST['valor'];
    $num = $_POST["valor"];
    $aleatorio = $_SESSION["aleatorio"];

    if($num < $aleatorio){
        echo "O valor $num é menor que o valor secreto";
    }
    else if($num > $aleatorio){
        echo "O valor $num é maior que o valor secreto";
    }
    else{
        echo "Você acertou o valor secreto";
    }
}