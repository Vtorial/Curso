<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabalho Q03</title>
</head>
<body>

<php>
    escreva um valor entre 1 e 10;
</php>
<form method="POST">
     
<label>Digite um valor:</label><br>
        <?php
            for ($i=0; $i < 20; $i++) { 
                echo "<input type='number' name='number[]' max ='10' min = '1' required><br>";
            }
           
        ?>
        <br> 
        <label>digite o número que queira adivinhar</label>
        <input type="number" name="adivinhar">

        <input type="submit" value="enviar" >
        <br>
    </form>

</body>
</html>

<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
$num = $_POST["number"];
$adivinhar = $_POST["adivinhar"];
$adivinhar = $_POST['adivinhar'];
    for ($i = 0; $i < 20; $i++) { 
       $matriz[$i] = $num[$i];
    }
}
echo "<br>";
echo "<br>";
echo "<br>";

if (in_array($adivinhar, $matriz)) {
    $valores = array_keys($matriz, $adivinhar);
    echo "o numero está nos respectivos indices; <br> ";
    $valor = implode('° indice ', $valores); //coloca entre os valores, nao coloca no valor final
    echo "$valor";
    echo "° indice";
}else {
    echo "o numero não está na martriz <br>";
}
