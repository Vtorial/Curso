<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trabalho Q10</title>
</head>
<body>
    
<form method="POST">
        <label>Digite alguma palavra:</label>
        <input type="string" name="palavra" required><br>
        <br>
        <input type="submit" value="enviar">
        <br>
    </form>

</body>
</html>

<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){

 $palavra = $_POST["palavra"];
 $reverse = strrev ($palavra);
 if ($reverse === $palavra){
 echo "$palavra é políndroma";}
    else {
        echo"$palavra não é políndroma";}
    
}
