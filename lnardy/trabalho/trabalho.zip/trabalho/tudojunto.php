<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Botões</title>
</head>
<body>
    
<form action="q1.php">
    <button type="submit">Q01</button>
</form>
<form action="q2.php">
    <button type="submit">Q02</button>
</form>
<form action="q3.php">
    <button type="submit">Q03</button>
</form>
<form action="q4.php">
    <button type="submit">Q04</button>
</form>
<form action="q5.php">
    <button type="submit">Q05</button>
</form>
<form action="q6.php">
    <button type="submit">Q06</button>
</form>
<form action="q7.php">
    <button type="submit">Q07</button>
</form>
<form action="q8.php">
    <button type="submit">Q08</button>
</form>
<form action="q9.php">
    <button type="submit">Q09</button>
</form>
<form action="q10.php">
    <button type="submit">Q10</button>
</form>
<form action="q11.php">
    <button type="submit">Q11</button>
</form>
<form action="q12.php">
    <button type="submit">Q12</button>
</form>
<form action="q13.php">
    <button type="submit">Q13</button>
</form>
<form action="q14.php">
    <button type="submit">Q14</button>
</form>

</body>
</html>